package net.yanhl.finance.service;


/**
 * <p>Title: 借入业务接口
 * Description:
 * 
 * @author 闫洪磊
 */
public interface FinanceInManager extends FinanceManager{

}
