package net.yanhl.tree.util;

/**
 * 下拉树工具类
 * @author 闫洪磊
 * @since Nov 28, 2008
 *
 */
public class TreeUtil {
	public static final int TYPE_GROUP = 0;//组类型
	public static final int TYPE_USER = 1;//用户类型
}
