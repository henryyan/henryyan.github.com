package net.yanhl.finance.util;

/**
 * <p>Title: 账务工具类</p>
 * <p>Description: </p>
 * @author	闫洪磊
 * @version	1.0.0.20081212
*/
public class FinanceUtil {
	public static final Integer FINANCE_IN = 0;
	public static final Integer FINANCE_OUT = 1; 
}
