package net.yanhl.finance.dao;

/**
 * <p>Title: 账务借入DAO接口</p>
 * <p>Description:即借别人的钱</p>
 * <p>Copyright: Copyright (c) 2008</p>
 * 
 * @author 闫洪磊
 * @version 1.0.0.20080720
 */
public interface FinanceInDao extends FinanceDao{
	
}
