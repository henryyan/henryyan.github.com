package net.yanhl.util;

public class SysConstants {
}
