package net.yanhl.finance.service;

/**
 * <p>Title: 账务借出业务接口</p>
 * <p>Description:</p>
 * <p>Copyright: Copyright (c) 2008</p>
 * 
 * @author 闫洪磊
 * @version 1.0.0.20081220
 */
public interface FinanceOutManager {

}
