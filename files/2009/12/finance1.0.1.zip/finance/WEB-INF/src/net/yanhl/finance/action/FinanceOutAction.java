package net.yanhl.finance.action;


/**
 * <p>Title: 账务借出ACTION</p>
 * <p>Description:</p>
 * <p>Copyright: Copyright (c) 2008</p>
 * 
 * @author 闫洪磊
 * @version 1.0.0.20080720
 */
public class FinanceOutAction extends FinanceBaseAction {

}
