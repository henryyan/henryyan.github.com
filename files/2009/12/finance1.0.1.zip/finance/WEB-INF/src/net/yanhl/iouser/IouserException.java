package net.yanhl.iouser;

/**
 * 债务人异常
 * @author 闫洪磊
 * @since Dec 26, 2008
 *
 */
public class IouserException extends Exception {

	public IouserException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public IouserException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
